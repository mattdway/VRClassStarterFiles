using UnityEngine;

public class TargetDebug : MonoBehaviour
{
    [SerializeField, Range(0, 0.5f)] private float distance = 0.25f;

    private void OnDrawGizmos()
    {
        Gizmos.DrawRay(transform.position, Vector3.up * distance);
    }
}

﻿using UnityEngine;

public class Projectile : MonoBehaviour
{
    [SerializeField] private float launchForce = 10.0f;
    [SerializeField] private float lifeTime = 5.0f;

    public void Launch()
    {
        if (TryGetComponent(out Rigidbody rigidbody))
        {
            rigidbody.AddRelativeForce(Vector3.forward * launchForce, ForceMode.Impulse);
            Destroy(gameObject, lifeTime);
        }
    }
}

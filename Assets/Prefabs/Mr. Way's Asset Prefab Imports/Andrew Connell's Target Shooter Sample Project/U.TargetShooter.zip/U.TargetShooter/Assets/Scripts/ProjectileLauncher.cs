using UnityEngine;

public class ProjectileLauncher : MonoBehaviour
{
    [SerializeField] private GameObject prefab;
    [SerializeField] private Transform origin;

    public void FireProjectile()
    {
        GameObject projectileObject = Instantiate(prefab, origin.position, origin.rotation);

        if (projectileObject.TryGetComponent(out Projectile projectile))
            projectile.Launch();
    }
}
